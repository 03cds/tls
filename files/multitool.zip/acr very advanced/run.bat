@echo off

pip install rich --quiet --disable-pip-version-check >nul 2>&1

pip install requests keyboard --quiet --disable-pip-version-check >nul 2>&1

pip install rich requests --quiet --disable-pip-version-check >nul 2>&1


python acr.py 


pause