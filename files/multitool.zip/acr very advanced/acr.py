import mmap
import re
import shutil
import pathlib
import string
import random
import time
import requests
import tkinter as tk
from tkinter import filedialog
from datetime import datetime, UTC
import msvcrt
import uuid
import json

from rich.console import Console
from rich.prompt import IntPrompt, Prompt
from rich.panel import Panel
from rich.table import Table
from rich.progress import (
    Progress,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    ProgressColumn,
)
from rich.align import Align


console = Console()

TARGETS_FILE = pathlib.Path("targets.txt")
BACKUP_EXT = ".undo"
CATALOG_FILE = pathlib.Path("catalog.json")

MAIN_RED = "red3"
ACCENT_RED = "indian_red1"
DIM_RED = "red"

MIN_PLAYFAB_INTERVAL = 0.01

PRINTABLE_RE = re.compile(rb"[ -~]{4,}")
SEMANTIC_RE = re.compile(
    rb"(^[A-Z][A-Za-z0-9_]+$)|"
    rb"(^static\s+void\s+[A-Za-z_][A-Za-z0-9_]*)|"
    rb"(^[A-Za-z_][A-Za-z0-9_]*\.cs$)"
)


class StableETAColumn(ProgressColumn):
    def __init__(self):
        super().__init__()
        self.start = time.time()
        self.ema_rate = None
        self.alpha = 0.2
        self.delay = 5.0

    def render(self, task):
        elapsed = time.time() - self.start
        if elapsed < self.delay:
            return ""
        completed = task.completed or 0
        if completed <= 0 or not task.total:
            return ""
        rate = completed / max(elapsed, 1e-6)
        self.ema_rate = rate if self.ema_rate is None else (
            self.alpha * rate + (1 - self.alpha) * self.ema_rate
        )
        remaining = int((task.total - completed) / max(self.ema_rate, 1e-6))
        return f"ETA: {remaining} SECONDS UNTIL DONE"


def logo():
    art = r"""
████████╗██╗  ██╗██╗███╗   ██╗ ██████╗ ██╗   ██╗
╚══██╔══╝██║  ██║██║████╗  ██║██╔════╝ ╚██╗ ██╔╝
   ██║   ███████║██║██╔██╗ ██║██║  ███╗ ╚████╔╝
   ██║   ██╔══██║██║██║╚██╗██║██║   ██║  ╚██╔╝
   ██║   ██║  ██║██║██║ ╚████║╚██████╔╝   ██║
   ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝ ╚═════╝    ╚═╝
"""
    console.print(
        Panel(
            Align.center(
                f"[bold {ACCENT_RED}]{art}[/]\n[{DIM_RED}]fella/thingy anti remover v1.85[/]"
            ),
            border_style=MAIN_RED,
        )
    )


def show_help():
    console.print(
        Panel(
            Align.left(
                f"""
[{ACCENT_RED}]MODES[/]

wipe             → scan + remove targets
scan             → scan only, no changes
pfspam  → loop register accounts
catalog  → login + pull catalog (saved)

[{ACCENT_RED}]SCAN CONTROLS[/]
number → toggle target
go     → wipe enabled
undo   → restore backup
help   → this screen
quit   → exit

[{ACCENT_RED}]WIPE MODES[/]
1 → Spaces
2 → Null bytes
3 → Random letters

[{DIM_RED}]Backup always created for wipe.[/]
"""
            ),
            title="Help",
            border_style=MAIN_RED,
        )
    )


def load_targets():
    if not TARGETS_FILE.exists():
        TARGETS_FILE.write_text(
            "\n".join([
                "EasyAntiCheat",
                "AntiCheat",
                "DLL_Checker",
                "IsModded",
                "MelonLoader",
                "SolarAntiCheat",
                "PhotonAuth",
                "VersionChecker",
                "UnitysAntiCheat",
            ]),
            encoding="utf-8",
        )
    return [
        t.encode()
        for t in TARGETS_FILE.read_text(encoding="utf-8").splitlines()
        if t.strip()
    ]


def pick_file():
    root = tk.Tk()
    root.withdraw()
    f = filedialog.askopenfilename(
        title="Select Unity file",
        filetypes=[("Unity files", "*.unity3d"), ("All files", "*.*")]
    )
    root.destroy()
    return pathlib.Path(f) if f else None


def scan_semantic(path, targets):
    hits = {t: [] for t in targets}
    tgt_re = re.compile(rb"(" + b"|".join(map(re.escape, targets)) + rb")")

    with path.open("rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as m:
        total = sum(1 for _ in PRINTABLE_RE.finditer(m))
        m.seek(0)

        with Progress(
            StableETAColumn(),
            SpinnerColumn(style=ACCENT_RED),
            TextColumn(f"[{MAIN_RED}]Scanning[/]"),
            BarColumn(bar_width=None, style=ACCENT_RED),
            console=console,
        ) as progress:
            task = progress.add_task("scan", total=total)

            for match in PRINTABLE_RE.finditer(m):
                progress.advance(task)
                chunk = match.group()
                if not SEMANTIC_RE.match(chunk):
                    continue
                for tm in tgt_re.finditer(chunk):
                    hits[tm.group(1)].append(match.start() + tm.start())

    return {k: v for k, v in hits.items() if v}


def wipe(data, hits, mode):
    count = 0
    for word, pos_list in hits.items():
        ln = len(word)
        for pos in pos_list:
            if mode == 1:
                data[pos:pos + ln] = b" " * ln
            elif mode == 2:
                data[pos:pos + ln] = b"\x00" * ln
            else:
                data[pos:pos + ln] = bytes(
                    random.choice(string.ascii_letters).encode()
                    for _ in range(ln)
                )
            count += 1
    return count


def pfspam():
    console.print(
        Panel(
            "[bold red]PlayFab Request Loop[/]\n"
            "• New account every loop\n"
            "• 1.26s minimum per attempt\n"
            "• Press H to stop",
            border_style=MAIN_RED,
        )
    )

    title_id = Prompt.ask("PlayFab Title ID").strip()
    url = f"https://{title_id}.playfabapi.com/Client/LoginWithCustomId"

    while True:
        start = time.monotonic()

        if msvcrt.kbhit() and msvcrt.getch().lower() == b"h":
            console.print("[bold red]Stopped[/]")
            break

        payload = {
            "TitleId": title_id,
            "CustomId": str(uuid.uuid4()),
            "CreateAccount": True,
        }

        ok = False
        for _ in range(2):
            try:
                r = requests.post(url, json=payload, timeout=10)
                ok = (
                    r.status_code == 200
                    and "SessionTicket" in r.json().get("data", {})
                )
                if ok:
                    break
            except Exception:
                pass

        console.print(f"[{ACCENT_RED}]{'Registered' if ok else 'Failed'}[/]")

        elapsed = time.monotonic() - start
        if elapsed < MIN_PLAYFAB_INTERVAL:
            time.sleep(MIN_PLAYFAB_INTERVAL - elapsed)


def catalog():
    console.print(
        Panel(
            "[bold red]PlayFab Catalog Pull[/]\n"
            "• One-time login\n"
            "• Saves catalog to JSON",
            border_style=MAIN_RED,
        )
    )

    title_id = Prompt.ask("PlayFab Title ID").strip()
    custom_id = Prompt.ask("Custom ID (anything)", default=str(uuid.uuid4()))

    login_url = f"https://{title_id}.playfabapi.com/Client/LoginWithCustomId"
    catalog_url = f"https://{title_id}.playfabapi.com/Client/GetCatalogItems"

    r = requests.post(
        login_url,
        json={
            "TitleId": title_id,
            "CustomId": custom_id,
            "CreateAccount": True,
        },
        timeout=10,
    )

    data = r.json().get("data", {})
    ticket = data.get("SessionTicket")
    if not ticket:
        console.print("[red]Login failed[/]")
        return

    r = requests.post(
        catalog_url,
        json={"TitleId": title_id},
        headers={"X-Authorization": ticket},
        timeout=10,
    )

    catalog = r.json().get("data", {}).get("Catalog", [])
    CATALOG_FILE.write_text(
        json.dumps(
            {
                "titleId": title_id,
                "fetchedAt": datetime.now(UTC).isoformat(),
                "count": len(catalog),
                "catalog": catalog,
            },
            indent=4,
        ),
        encoding="utf-8",
    )

    console.print(
        Panel(
            f"[bold {ACCENT_RED}]Catalog Saved[/]\nItems: {len(catalog)}\nFile: {CATALOG_FILE}",
            border_style=MAIN_RED,
        )
    )


def main():
    logo()

    mode = Prompt.ask(
        "Select mode",
        choices=["wipe", "scan", "pfspam", "catalog"],
        default="wipe",
    )

    if mode == "pfspam":
        pfspam()
        return

    if mode == "catalog":
        catalog()
        return

    show_help()

    targets = load_targets()
    path = pick_file()
    if not path:
        return

    hits = scan_semantic(path, targets)
    if not hits:
        console.print("[green]No targets found[/green]")
        return

    if mode == "scan":
        console.print("[bold green]Scan complete. No changes made.[/]")
        return

    wipe_mode = IntPrompt.ask(
        "1) Spaces  2) Nulls  3) Random",
        choices=["1", "2", "3"]
    )

    backup = path.with_suffix(path.suffix + BACKUP_EXT)
    shutil.copy2(path, backup)

    data = bytearray(path.read_bytes())
    changed = wipe(data, hits, int(wipe_mode))
    path.write_bytes(data)

    console.print(
        Panel(
            f"[bold {ACCENT_RED}]Done[/]\nModified strings: {changed}",
            border_style=MAIN_RED,
        )
    )


if __name__ == "__main__":
    main()
